# frozen_string_literal: true

module HomeHelper
end
