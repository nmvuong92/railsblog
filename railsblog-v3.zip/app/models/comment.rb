# frozen_string_literal: true

class Comment < ApplicationRecord
end
