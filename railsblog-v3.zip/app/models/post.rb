# frozen_string_literal: true

class Post < ApplicationRecord
end
