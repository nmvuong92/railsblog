# frozen_string_literal: true

class Widget < ApplicationRecord
end
