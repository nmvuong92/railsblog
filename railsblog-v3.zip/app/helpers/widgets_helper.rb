# frozen_string_literal: true

module WidgetsHelper
end
